function display(f)
%DISPLAY Display the members of a composite map.

fprintf('\n%s = composite of the sequence:\n',inputname(1))
disp(f)
