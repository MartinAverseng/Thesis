function m = members(f)

m = f.maps;
