function scparopt(varargin)
%SCPAROPT is defunct. Use SCMAPOPT instead.

help scparopt


