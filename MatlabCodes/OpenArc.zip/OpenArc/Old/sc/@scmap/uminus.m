function M = uminus(M)
%   Negate the image of an SC map.

%   Copyright (c) 1998 by Toby Driscoll.
%   $Id: uminus.m 298 2009-09-15 14:36:37Z driscoll $

M = (-1)*M;