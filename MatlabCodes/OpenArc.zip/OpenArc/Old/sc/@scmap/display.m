function display(f)

% $Id: display.m 298 2009-09-15 14:36:37Z driscoll $ 

fprintf('\n%s =\n',inputname(1))
disp(f)
