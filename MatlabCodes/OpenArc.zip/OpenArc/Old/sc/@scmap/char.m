function s = char(f)

s = '  scmap object (generic)';
