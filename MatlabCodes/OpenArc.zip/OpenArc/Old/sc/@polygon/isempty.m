function t = isempty(p)
%   Returns true if there are no vertices.

%   Copyright 1998 by Toby Driscoll.
%   $Id: isempty.m 298 2009-09-15 14:36:37Z driscoll $

t = isempty(p.vertex);
