function pr = rectpoly(M)
%   Return rectified polygon.

%   Copyright 1998 by Toby Driscoll.
%   $Id: rectpoly.m 298 2009-09-15 14:36:37Z driscoll $

pr = M.rectpolygon;
