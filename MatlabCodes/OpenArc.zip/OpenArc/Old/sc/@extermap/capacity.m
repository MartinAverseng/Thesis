function g = capacity(map)

g = abs(map.constant);
