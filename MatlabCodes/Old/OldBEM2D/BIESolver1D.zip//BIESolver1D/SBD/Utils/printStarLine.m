function[] = printStarLine()
fprintf('********************************************* \n')
end