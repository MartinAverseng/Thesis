lambdaMax = [];

for N = fix(10.^(1:0.5:4))

P = (1:N)';
Q = P';
A = (P*Q).^(1.5)./(abs(repmat(P,1,N) - repmat(Q,N,1)).*abs(repmat(P,1,N) + repmat(Q,N,1)));
A(1:N+1:end) = 0;

lambdaMax = [lambdaMax; max(eig(A))];

end

loglogTrislope(fix(10.^(1:0.5:4)),lambdaMax);


%% Evolution du nombre critique jimbo pour le conditionnement de a
jimbos = [];
for P = fix(10.^(1:0.5:4))
    rho = besselJroots(0,P);
    condA = 0;
    i = 2;
    while condA < 1e10
        i = i+0.5;
        a = i/(pi*P);
        A = gramMatrix(a,1,rho);
        condA = cond(A);
    end
    jimbos(end+1) = i;
end