close all;
clear all;

a_values = [0.1; 0.05; 0.02; 0.01; 0.005; 0.002; 0.001; 1e-4; 3e-5; 1e-5; 3e-6; 1e-6];
nValues = length(a_values);

for i = 1:nValues
    a = a_values(i);
    P_values = linspace(10,max(11,fix(5/a)),100);
    P_values = unique(fix(P_values));
    condAab{i} = [];
    for j = 1:length(P_values)
        P = P_values(j);
        rho = besselJroots(0,P);
        b = 1;
        A = gramMatrix(a,b,rho);
        condRef = cond(gramMatrix(a,b,rho));        
        step = a;
        direction = -1;
        tol = a/15;
        while step > tol
            b = b + direction*step;
            Aab = gramMatrix(a,b,rho);
            if direction*(cond(Aab)  - 100*condRef)<0
                direction = -direction;
                step = step/2;
            end            
        end
        bP{i}(j) = b;
    end
    
    close all
    plot(P_values,bP{i});
    hold on
    plot(P_values,1-a + 0*P_values);
    plot(P_values,1-a/2 + 0*P_values);
    ylim([1-2*a,1])
end