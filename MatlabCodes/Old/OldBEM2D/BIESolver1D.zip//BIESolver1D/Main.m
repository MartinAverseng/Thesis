addpath(genpath(pwd));
addpath(genpath('/home/martin/MatlabCodes/usefulMatlabFunctions'));
disp('Hello !');
clear all; %#ok
close all;
clc;