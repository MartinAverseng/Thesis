function [ out ] = StruveH_moins1(x)

out = - StruveH1(x) + 1/(sqrt(pi)*gamma(3/2));


end

