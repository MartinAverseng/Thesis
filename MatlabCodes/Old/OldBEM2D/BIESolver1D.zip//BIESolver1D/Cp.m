function[C] = Cp(rho)

C = 1./(sqrt(pi)*rho.*besselj(1,rho));

end