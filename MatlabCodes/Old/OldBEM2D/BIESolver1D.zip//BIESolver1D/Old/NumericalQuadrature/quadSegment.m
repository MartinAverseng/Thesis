function [ x,w ] = quadSegment(quadRule)

[x,w] = feval(quadRule);

end

