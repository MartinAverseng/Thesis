function[angles] = anglesTcheb(N)
angles = (0:N-1)'*pi/(N-1);
end