function [fe_func] = variationalSol(b,l)
% Solves the variational problem b(u,v) = l(v) 
% for all v in the space of functions on which both b and l are defined. 
% returns a FE_func object containing the coordinates of this solution

assert(isa(b,'BilinearForm'));
assert(isa(l,'LinearForm'));
assert(isequal(b.feSpace,l.feSpace));

x = b\full(l)';

fe_func = FE_func(b.feSpace,x);


end

