classdef LinearForm < AbstractMatrix
    % a linear form is a function defined on a FE space, that accepts
    % FE_func arguments defined on the same FE space and returns a scalar.
    
    properties
        feSpace@FEspace;
        savedValues;
    end
    
    methods
        function[this] = LinearForm(Vh,values)
            this.feSpace = Vh;
            this.mv_prod = @(x)(values*x);
            this.savedValues = values;
            this.N1 = 1;
            this.N2 = Vh.ndof;
        end
        function[r] = eval(this,u)
            assert(isa(u,'FE_func'));
            errorMessage = 'This linear form is not defined on the same FE space as argument ''u''';
            assert(isequal(u.feSpace,this.feSpace),errorMessage);
            r = this.savedValues*u.v;
        end
        function[out] = or(this,u)
            out = this.eval(u);
        end
        function[v] = full(this)           
            v = this.savedValues;            
        end
        function[C] = plus(this,l)
            if isequal(class(this),'LinearForm')
                switch class(l)
                    case 'LinearForm'
                        assert(isequal(this.feSpace,l.feSpace),...
                            'The linear forms are not defined on the same FE space')
                        C = this;
                        vals = this.savedValues + l.savedValues;
                        C.savedValues = vals;
                        C.mv_prod = @(x)(vals*x);
                    case 'func'
                        l_new = this.feSpace.secondMember(l);
                        C = this + l_new;
                    case 'FE_func'
                        l_new = this.feSpace.secondMember(l);
                        C = this + l_new;
                    case 'R2toRfunc'
                        l_new = this.feSpace.secondMember(l);
                        C = this + l_new;
                    case 'double'
                        C = this;
                        vals = this.savedValues + l;
                        C.savedValues = vals;
                        C.mv_prod = @(x)(vals*x);
                end
            elseif isequal(class(l),'LinearForm')
                C = plus(l,this);
            end
        end
        function[C] = mtimes(this,u)
            if isa(u,'FE_func')
                C = this.eval(u);
            elseif and(isa(u,'double'),isscalar(u))
                C = this;
                C.mv_prod = @(x)(u*this.mv_prod(x));
            elseif isa(this,'double')
                C = mtimes(u,this);
            else
                % The result is no longer a linear form, but still an
                % abstract matrix.
                assert(size(this,2)==size(u,1));
                C = AbstractMatrix(@(x)(this.mv_prod(u*x)),1,size(u,2));
            end
        end
    end
end
















