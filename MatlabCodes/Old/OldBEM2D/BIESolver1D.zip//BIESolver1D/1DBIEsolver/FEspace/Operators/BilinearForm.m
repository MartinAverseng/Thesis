classdef BilinearForm < AbstractMatrix
    % a bilinear form is a function defined on a Geometry and that return to
    % every pair of FE_func object (u,v) defined on the same geometry a real value
    % approximately equal to \int_{mesh}\int_{mesh} G(x,y)u(x)v(y)dy
    
    properties
        feSpace@FEspace;
    end
    
    methods
        function[this] = BilinearForm(Vh,mv_p)
            this.feSpace = Vh;
            this.mv_prod = mv_p;
            this.N1 = Vh.ndof;
            this.N2 = Vh.ndof;
        end
        function[C] = mtimes(A,B)
            if isa(A,'BilinearForm')
                if isa(B,'FE_func')
                    C = LinearForm(A.feSpace,A.mv_prod(B.v)');
                elseif isa(B,'double')
                    C = mtimes@AbstractMatrix(A,B);
                else
                    error(...
                        ['wrong type of argument, expected ''FE_func'' or scalar ''double'','...
                        'received %s instead'],...
                        class(B));
                end
            else
                % B is then a Bilinear form, so A must be a scalar double.
                assert(and(isa(A,'double'),isscalar(A)),sprintf(...
                    ['wrong type of argument, expected ''FE_func'' or scalar ''double'','...
                    'received %s instead'],...
                    class(B)));
                C = mtimes@AbstractMatrix(A,B);                
            end
        end
        function[out] = eval(this,uh,vh)
            Vh = this.feSpace;
            assert(Vh.contains(uh)); assert(Vh.contains(vh));
            out = (this.mv_prod(uh.v))'*vh.v;
        end
    end
    
end





