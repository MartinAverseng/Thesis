function [ q ] = inputOrDefaultQuad(T)

p = inputParser;
p.addOptional('quadrature',NumericalQuadrature(3));
p.KeepUnmatched = 1;
p.parse(T{:});
vars = p.Results;
q = vars.quadrature;
if isa(q,'double')
    q = NumericalQuadrature(q);
else
    assert(isa(q,'NumericalQuadrature'));
end


end

