% Validate the single layer potential on the circle.

Main;
N = 300;
q = 3;

curve = circle(1,[0,0]);
mesh = MeshCurve(curve,N);


Xh = FEspace(mesh,'P0',q);
Vh = FEspace(mesh,'P1',q);
Wh = FEspace(mesh,'P2',q);

k = 10;

T = Vh.doubleLayerPotential;
S0Nocompress = Xh.singleLayerPotential(0,'compressSBD',false);
S0compress = Xh.singleLayerPotential(0,'compressSBD',true);
S1Nocompress = Vh.singleLayerPotential(k,'compressSBD',false);
S1compress = Vh.singleLayerPotential(k,'compressSBD',true);
S2 = Wh.singleLayerPotential();



u0_func = @(Z)(sqrt(pi/2)*besselj(0,k*sqrt(Z(:,1).^2 + Z(:,2).^2)));%(Z(:,1).^6 - 15*Z(:,1).^4.*Z(:,2).^2 + 15*Z(:,1).^2.*Z(:,2).^4 - Z(:,2).^6);
u0 = R2toRfunc(u0_func);

lambda_func = @(Z)(-k*sqrt(pi/2)*besselj(1,k*sqrt(Z(:,1).^2 + Z(:,2).^2)));
lambda_theo = R2toRfunc(lambda_func); % 12*u0; 


l0 = Xh.secondMember(u0);
l1 = Vh.secondMember(u0);
l2 = Wh.secondMember(u0);


t0 = tic;
lambda0 = variationalSol(S0,l0);
t0 = toc(t0);
t1 = tic;
lambda1 = variationalSol(S1,l1);
t1 = toc(t1);
t2 = tic;
lambda2 = variationalSol(S2,l2);
t2 = toc(t2);

err1 = sqrt(lambda0 - lambda_theo|lambda0 - lambda_theo);
err2 = sqrt(lambda1 - lambda_theo|lambda1 - lambda_theo);
err3 = sqrt(lambda2 - lambda_theo|lambda2 - lambda_theo);


























































